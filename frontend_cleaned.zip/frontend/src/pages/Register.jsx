import RegisterForm from '../components/forms/RegisterForm'

const Register = () => {
    return (
        <div className="flex justify-center items-center h-screen bg-[#8B0000]">
            <RegisterForm />
        </div>
    )
}

export default Register
